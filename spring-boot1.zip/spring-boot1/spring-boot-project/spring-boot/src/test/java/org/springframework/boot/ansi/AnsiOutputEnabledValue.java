/*
 * Copyright 2012-2017 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.boot.ansi;

import org.springframework.boot.ansi.AnsiOutput.Enabled;

/**
 * Public access to {@link AnsiOutput#getEnabled()} for other tests to use.
 *
 * @author Phillip Webb
 */
public final class AnsiOutputEnabledValue {

	private AnsiOutputEnabledValue() {
	}

	public static Enabled get() {
		return AnsiOutput.getEnabled();
	}

}
