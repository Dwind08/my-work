package com.zhaowa.spring.beans.factory;

import com.zhaowa.spring.beans.factory.config.BeanDefinition;
import com.zhaowa.spring.beans.BeansException;

public interface BeanFactory {
    Object getBean(String beanName) throws BeansException;
    void registerBeanDefinition(BeanDefinition beanDefinition);
}
