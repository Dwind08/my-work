package com.zhaowa.spring.beans.factory.config;

public class BeanDefinition {
    private String id;
    private String className;
    public BeanDefinition() {}
    public BeanDefinition(String id, String className) {
        this.id = id;
        this.className = className;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }
}
//省略getter和setter
