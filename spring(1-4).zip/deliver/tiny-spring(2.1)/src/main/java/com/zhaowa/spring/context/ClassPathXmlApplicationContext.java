package com.zhaowa.spring.context;

import com.zhaowa.spring.beans.BeansException;
import com.zhaowa.spring.beans.factory.BeanFactory;
import com.zhaowa.spring.beans.factory.SimpleBeanFactory;
import com.zhaowa.spring.beans.factory.xml.XmlBeanDefinitionReader;
import com.zhaowa.spring.core.ClassPathXmlResource;
import com.zhaowa.spring.core.Resource;

public class ClassPathXmlApplicationContext implements BeanFactory, ApplicationEventPublisher {
    BeanFactory beanFactory;
    //context负责整合容器的启动过程，读外部配置，解析Bean定义，创建BeanFactory
    public ClassPathXmlApplicationContext(String fileName) {
        Resource resource = new ClassPathXmlResource(fileName);
        SimpleBeanFactory beanFactory = new SimpleBeanFactory();
        XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(beanFactory);
        reader.loadBeanDefinitions(resource);
        this.beanFactory = beanFactory;
    }
    //context再对外提供一个getBean，底下就是调用的BeanFactory对应的方法
    public Object getBean(String beanName) throws BeansException {
        return this.beanFactory.getBean(beanName);
    }
    public boolean containsBean(String name) {
        return this.beanFactory.containsBean(name);
    }
    public void publishEvent(ApplicationEvent event) {
    }
    public boolean isSingleton(String name) {
        return false;
    }
    public boolean isPrototype(String name) {
        return false;
    }
    public Class<?> getType(String name) {
        return null;
    }
}
