package com.zhaowa.test;

public class AServiceImpl implements AService {

    private String name;
    private int level;
    private String property1;

    public void setProperty1(String property1) {
        this.property1 = property1;
    }
    private String property2;

    public void setProperty2(String property2) {
        this.property2 = property2;
    }
    public AServiceImpl(String name, int level) {
        this.name = name;
        this.level = level;
    }
    public AServiceImpl() {}
    public void sayHello() {
        System.out.println("a service 1 say hello");
    }
}
