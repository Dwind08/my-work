package com.zhaowa.spring.context;

import com.zhaowa.spring.beans.BeansException;
import com.zhaowa.spring.beans.factory.BeanFactory;
import com.zhaowa.spring.beans.factory.SimpleBeanFactory;
import com.zhaowa.spring.beans.factory.config.BeanDefinition;
import com.zhaowa.spring.beans.factory.xml.XmlBeanDefinitionReader;
import com.zhaowa.spring.core.ClassPathXmlResource;
import com.zhaowa.spring.core.Resource;

public class ClassPathXmlApplicationContext implements BeanFactory {
    BeanFactory beanFactory;
    //context负责整合容器的启动过程，读外部配置，解析Bean定义，创建BeanFactory
    public ClassPathXmlApplicationContext(String fileName) {
        Resource resource = new ClassPathXmlResource(fileName);
        BeanFactory beanFactory = new SimpleBeanFactory();
        XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(beanFactory);
        reader.loadBeanDefinitions(resource);
        this.beanFactory = beanFactory;
    }
    //context再对外提供一个getBean，底下就是调用的BeanFactory对应的方法
    public Object getBean(String beanName) throws BeansException {
        return this.beanFactory.getBean(beanName);
    }
    public Boolean containsBean(String name) {
        return this.beanFactory.containsBean(name);
    }
    public void registerBean(String beanName, Object obj) {
        this.beanFactory.registerBean(beanName, obj);
    }
    public void registerBeanDefinition(BeanDefinition beanDefinition) {
        this.beanFactory.registerBeanDefinition(beanDefinition);
    }
}
