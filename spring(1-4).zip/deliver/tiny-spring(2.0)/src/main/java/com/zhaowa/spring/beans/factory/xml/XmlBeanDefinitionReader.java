package com.zhaowa.spring.beans.factory.xml;

import com.zhaowa.spring.beans.factory.BeanFactory;
import com.zhaowa.spring.beans.factory.SimpleBeanFactory;
import com.zhaowa.spring.beans.factory.config.BeanDefinition;
import com.zhaowa.spring.core.Resource;
import org.dom4j.Element;

public class XmlBeanDefinitionReader {
    BeanFactory simpleBeanFactory;
    public XmlBeanDefinitionReader(BeanFactory simpleBeanFactory) {
        this.simpleBeanFactory = simpleBeanFactory;
    }
    public void loadBeanDefinitions(Resource resource) {
        while (resource.hasNext()) {
            Element element = (Element) resource.next();
            String beanID = element.attributeValue("id");
            String beanClassName = element.attributeValue("class");
            BeanDefinition beanDefinition = new BeanDefinition(beanID, beanClassName);
            this.simpleBeanFactory.registerBeanDefinition(beanDefinition);
        }
    }
}
