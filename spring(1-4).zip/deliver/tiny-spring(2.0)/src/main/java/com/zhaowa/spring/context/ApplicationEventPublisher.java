package com.zhaowa.spring.context;

public interface ApplicationEventPublisher {
    void publishEvent(ApplicationEvent event);
}
