package com.zhaowa.spring.web;

import java.util.Iterator;
public interface Resource extends Iterator<Object>{
}
