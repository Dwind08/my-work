package com.zhaowa.test.controller;

public class HelloWorldBean {
    public String doGet() {
        return "hello world!";
    }
    public String doPost() {
        return "hello world!";
    }
}
