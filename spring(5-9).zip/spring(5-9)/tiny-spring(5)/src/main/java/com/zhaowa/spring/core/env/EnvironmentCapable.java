package com.zhaowa.spring.core.env;

public interface EnvironmentCapable {
    Environment getEnvironment();
}
