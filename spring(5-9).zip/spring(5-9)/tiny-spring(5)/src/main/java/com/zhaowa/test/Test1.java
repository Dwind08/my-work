package com.zhaowa.test;

import com.zhaowa.spring.beans.BeansException;
import com.zhaowa.spring.context.ClassPathXmlApplicationContext;

public class Test1 {

    public static void main(String[] args) throws BeansException {
        ClassPathXmlApplicationContext ctx = new
                ClassPathXmlApplicationContext("beans.xml");
        AService aService = (AService)ctx.getBean("aservice");
        aService.sayHello();
    }
}
