package com.zhaowa.test;

public interface AService {
    void sayHello();
}
