package com.zhaowa.spring.context;

import com.zhaowa.spring.beans.BeansException;
import com.zhaowa.spring.beans.factory.ListableBeanFactory;
import com.zhaowa.spring.beans.factory.config.BeanFactoryPostProcessor;
import com.zhaowa.spring.beans.factory.config.ConfigurableBeanFactory;
import com.zhaowa.spring.beans.factory.config.ConfigurableListableBeanFactory;
import com.zhaowa.spring.core.env.Environment;
import com.zhaowa.spring.core.env.EnvironmentCapable;

public interface ApplicationContext
        extends EnvironmentCapable, ListableBeanFactory,
        ConfigurableBeanFactory, ApplicationEventPublisher{
    String getApplicationName();
    long getStartupDate();
    ConfigurableListableBeanFactory getBeanFactory() throws
            IllegalStateException;
    void setEnvironment(Environment environment);
    Environment getEnvironment();
    void addBeanFactoryPostProcessor(BeanFactoryPostProcessor postProcessor);
    void refresh() throws BeansException, IllegalStateException;
    void close();
    boolean isActive();
}
