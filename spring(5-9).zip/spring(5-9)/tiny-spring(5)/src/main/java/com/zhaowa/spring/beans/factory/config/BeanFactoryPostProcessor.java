package com.zhaowa.spring.beans.factory.config;


import com.zhaowa.spring.beans.BeansException;
import com.zhaowa.spring.beans.factory.BeanFactory;

public interface BeanFactoryPostProcessor {
	void postProcessBeanFactory(BeanFactory beanFactory) throws BeansException;
}
