package com.zhaowa.spring.beans.factory.config;

import com.zhaowa.spring.beans.factory.ListableBeanFactory;

public interface ConfigurableListableBeanFactory
        extends ListableBeanFactory, AutowireCapableBeanFactory,
        ConfigurableBeanFactory {
}
