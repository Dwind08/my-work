package com.zhaowa.spring.web.servlet;

public class MethodParameter {
	private volatile Class<?> parameterType;
	private volatile String parameterName;
	private volatile Object parameterValue;
}
