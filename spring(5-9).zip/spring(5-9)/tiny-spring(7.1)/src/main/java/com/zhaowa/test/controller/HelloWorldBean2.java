package com.zhaowa.test.controller;

import com.zhaowa.spring.web.RequestMapping;

public class HelloWorldBean2 {
    @RequestMapping("/test2")
    public String doTest() {
        return "hello world for doGet2!";
    }
}
