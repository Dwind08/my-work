package com.zhaowa.spring.web.bind.support;

import com.zhaowa.spring.web.bind.WebDataBinder;

public interface WebBindingInitializer {
	void initBinder(WebDataBinder binder);
}
