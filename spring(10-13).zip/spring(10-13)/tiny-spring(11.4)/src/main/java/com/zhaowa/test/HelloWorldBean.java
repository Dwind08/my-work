package com.zhaowa.test;

import com.zhaowa.spring.web.bind.annotation.RequestMapping;
import com.zhaowa.spring.web.bind.annotation.ResponseBody;
import com.zhaowa.spring.web.servlet.ModelAndView;
import com.zhaowa.test.entity.User;

import java.util.Date;

public class HelloWorldBean {
    @RequestMapping("/test")
    public String doTest(User user) {
        return "hello world for doGet:" + user;
    }

    @RequestMapping("/test3")
    @ResponseBody
    public User doTest3(User user) {
        user.setName(user.getName() + "---");
        user.setBirthday(new Date());
        return user;
    }

    @RequestMapping("/test5")
    public ModelAndView doTest5(User user) {
        ModelAndView mav = new ModelAndView("test","msg",user.getName());
        return mav;
    }
    @RequestMapping("/test6")
    public String doTest6(User user) {
        return "error";
    }
}
