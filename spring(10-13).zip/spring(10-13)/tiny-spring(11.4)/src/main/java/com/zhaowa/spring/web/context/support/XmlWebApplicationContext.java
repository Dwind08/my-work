package com.zhaowa.spring.web.context.support;

import com.zhaowa.spring.context.ClassPathXmlApplicationContext;
import com.zhaowa.spring.web.context.WebApplicationContext;

import javax.servlet.ServletContext;

public class XmlWebApplicationContext
        extends ClassPathXmlApplicationContext implements WebApplicationContext {
    private ServletContext servletContext;

    public XmlWebApplicationContext(String fileName) {
        super(fileName);
    }

    public ServletContext getServletContext() {
        return this.servletContext;
    }
    public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
    }
}
