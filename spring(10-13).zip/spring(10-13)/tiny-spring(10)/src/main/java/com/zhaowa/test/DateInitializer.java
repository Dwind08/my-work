package com.zhaowa.test;

import com.zhaowa.spring.web.WebBindingInitializer;
import com.zhaowa.spring.web.WebDataBinder;

import java.util.Date;

public class DateInitializer implements WebBindingInitializer {
    public void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(Date.class, new CustomDateEditor(Date.class,"yyyy-MM-dd", false));
    }
}
