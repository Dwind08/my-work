package com.zhaowa.spring.web;

public interface WebBindingInitializer {
	void initBinder(WebDataBinder binder);
}
