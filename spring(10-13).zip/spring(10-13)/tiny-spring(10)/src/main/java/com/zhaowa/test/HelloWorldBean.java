package com.zhaowa.test;

import com.zhaowa.spring.web.RequestMapping;
import com.zhaowa.test.entity.User;

public class HelloWorldBean {
    @RequestMapping("/test")
    public String doTest(User user) {
        return "hello world for doGet:" + user;
    }
}
