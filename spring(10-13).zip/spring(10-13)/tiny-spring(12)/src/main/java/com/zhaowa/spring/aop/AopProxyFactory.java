package com.zhaowa.spring.aop;

public interface AopProxyFactory {
    AopProxy createAopProxy(Object target);
}
