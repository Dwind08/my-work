package com.zhaowa.spring.aop;

public interface AopProxy {
    Object getProxy();
}
