package com.zhaowa.spring.web.servlet;

public interface ViewResolver {
    View resolveViewName(String viewName) throws Exception;
}
