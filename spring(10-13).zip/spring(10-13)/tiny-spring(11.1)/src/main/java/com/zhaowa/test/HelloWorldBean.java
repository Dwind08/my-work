package com.zhaowa.test;

import com.zhaowa.spring.web.RequestMapping;
import com.zhaowa.spring.web.ResponseBody;
import com.zhaowa.test.entity.User;

import java.util.Date;

public class HelloWorldBean {
    @RequestMapping("/test")
    public String doTest(User user) {
        return "hello world for doGet:" + user;
    }

    @RequestMapping("/test3")
    @ResponseBody
    public User doTest3(User user) {
        user.setName(user.getName() + "---");
        user.setBirthday(new Date());
        return user;
    }
}
